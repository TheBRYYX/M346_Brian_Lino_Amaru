using System;
using System.IO;
using Amazon.S3;
using Amazon.S3.Model;
using System.Threading.Tasks;

public class ImageCompressorHandler : ILambdaFunction
{
    private readonly IAmazonS3 s3Client;
    private readonly string compressedBucketName;
    private readonly string uncompressedBucketName;

    public ImageCompressorHandler(IAmazonS3 s3Client, string compressedBucketName, string uncompressedBucketName)
    {
        this.s3Client = s3Client;
        this.compressedBucketName = compressedBucketName;
        this.uncompressedBucketName = uncompressedBucketName;
    }

    public async Task Invoke(ILambdaContext context)
    {
        var input = GetObjectRequest.ParseFromStream(context.Input);
        var uncompressedImageStream = input.RequestPayload;

        // Get the original image name
        var imageName = input.Key;

        // Compress the image
        var compressedImageStream = CompressImage(uncompressedImageStream);

        // Upload the compressed image to the compressed bucket
        var putObjectRequest = new PutObjectRequest
        {
            BucketName = compressedBucketName,
            Key = imageName
        };
        putObjectRequest.ContentLength = compressedImageStream.Length;
        putObjectRequest.InputStream = compressedImageStream;

        await s3Client.PutObjectAsync(putObjectRequest);

        // Delete the original image from the uncompressed bucket
        var deleteObjectRequest = new DeleteObjectRequest()
        {
            BucketName = uncompressedBucketName,
            Key = imageName
        };
        await s3Client.DeleteObjectAsync(deleteObjectRequest);
    }

    private MemoryStream CompressImage(Stream imageStream)
    {
        var compressedImageStream = new MemoryStream();

        // Use the JPEG compression algorithm
        var jpegEncoder = new JpegEncoder();
        jpegEncoder.Quality = 75;

        using (var encoderStream = jpegEncoder.CreateEncoderStream(compressedImageStream))
        {
            imageStream.CopyTo(encoderStream);
        }

        return compressedImageStream;
    }
}
